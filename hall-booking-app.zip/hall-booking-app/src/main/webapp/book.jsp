<%@ page import="java.util.*" %>
<html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>Book Function Hall</title><style>body{font-family:Arial;max-width:440px;margin:30px auto;padding:0 12px}input,select,button{width:100%;padding:9px;margin:6px 0;box-sizing:border-box}button{background:#2563eb;color:#fff;border:0;border-radius:4px}.msg{padding:8px;background:#e0f2fe;border-radius:4px}table{width:100%;border-collapse:collapse}td,th{border-bottom:1px solid #ddd;padding:6px;font-size:14px}a{color:#2563eb}</style></head>
<body>
<h2>Book a Function Hall</h2>
<p><a href="mybookings">My bookings</a></p>
<% String msg=(String)request.getAttribute("msg"); if(msg!=null){ %><p class="msg"><%= msg %></p><% } %>
<form method="post" action="book">
  <select name="hallId" required>
  <% List<String[]> halls=(List<String[]>)request.getAttribute("halls");
     if(halls!=null) for(String[] h:halls){ %>
    <option value="<%= h[0] %>"><%= h[1] %> - <%= h[2] %> guests - Rs.<%= h[3] %></option>
  <% } %>
  </select>
  <input name="name" placeholder="Your name" required>
  <input name="phone" placeholder="Phone" required>
  <input type="date" name="date" required>
  <input type="number" name="guests" placeholder="No. of guests" min="1" required>
  <button type="submit">Book Now</button>
</form>
</body></html>
