<%@ page import="java.util.*" %>
<html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>My Bookings</title><style>body{font-family:Arial;max-width:440px;margin:30px auto;padding:0 12px}input,select,button{width:100%;padding:9px;margin:6px 0;box-sizing:border-box}button{background:#2563eb;color:#fff;border:0;border-radius:4px}.msg{padding:8px;background:#e0f2fe;border-radius:4px}table{width:100%;border-collapse:collapse}td,th{border-bottom:1px solid #ddd;padding:6px;font-size:14px}a{color:#2563eb}</style></head>
<body>
<h2>My Bookings</h2>
<p><a href="book">Book a hall</a></p>
<form method="get" action="mybookings">
  <input name="phone" placeholder="Enter your phone" value="<%= request.getAttribute("phone") %>" required>
  <button type="submit">Search</button>
</form>
<% List<String[]> list=(List<String[]>)request.getAttribute("list");
   if(list!=null && !list.isEmpty()){ %>
<table><tr><th>Hall</th><th>Date</th><th>Guests</th><th>Status</th><th></th></tr>
<% for(String[] b:list){ %>
<tr><td><%= b[1] %></td><td><%= b[2] %></td><td><%= b[3] %></td><td><%= b[4] %></td>
<td><% if("CONFIRMED".equals(b[4])){ %>
<form method="post" action="mybookings" style="margin:0">
<input type="hidden" name="id" value="<%= b[0] %>">
<input type="hidden" name="phone" value="<%= request.getAttribute("phone") %>">
<button style="background:#dc2626;padding:4px">Cancel</button></form><% } %></td></tr>
<% } %></table>
<% } %>
</body></html>
