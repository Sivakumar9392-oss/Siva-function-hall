CREATE DATABASE IF NOT EXISTS hallbooking;
USE hallbooking;
CREATE TABLE halls (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100), capacity INT, price DECIMAL(10,2));
CREATE TABLE bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  hall_id INT, customer_name VARCHAR(100), phone VARCHAR(15),
  event_date DATE, guests INT, status VARCHAR(20) DEFAULT 'CONFIRMED',
  FOREIGN KEY (hall_id) REFERENCES halls(id));
INSERT INTO halls (name, capacity, price) VALUES
('Royal Hall',500,50000),('Garden Hall',300,30000),('Mini Hall',100,12000);
